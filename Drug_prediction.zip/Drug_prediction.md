```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

```


```python
df_drug=pd.read_csv(r"E:\Mass_EDA\drug200.csv")

```


```python
df_drug.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 200 entries, 0 to 199
    Data columns (total 6 columns):
     #   Column       Non-Null Count  Dtype  
    ---  ------       --------------  -----  
     0   Age          200 non-null    int64  
     1   Sex          200 non-null    object 
     2   BP           200 non-null    object 
     3   Cholesterol  200 non-null    object 
     4   Na_to_K      200 non-null    float64
     5   Drug         200 non-null    object 
    dtypes: float64(1), int64(1), object(4)
    memory usage: 9.5+ KB
    


```python
df_drug['Drug'].value_counts()
```




    Drug
    drugY    91
    drugX    54
    drugA    23
    drugC    16
    drugB    16
    Name: count, dtype: int64




```python
 df_drug.Sex.value_counts()
```




    Sex
    M    104
    F     96
    Name: count, dtype: int64




```python
df_drug.BP.value_counts()
```




    BP
    HIGH      77
    LOW       64
    NORMAL    59
    Name: count, dtype: int64




```python
skewAge = df_drug.Age.skew(axis = 0, skipna = True)
print('Age skewness: ', skewAge)
skewNatoK = df_drug.Na_to_K.skew(axis = 0, skipna = True)
print('Na to K skewness: ', skewNatoK)
```

    Age skewness:  0.03030835703000607
    Na to K skewness:  1.039341186028881
    


```python
sns.histplot(df_drug['Age'], kde=True)
plt.title('Age Distribution')
plt.xlabel('Age')
plt.ylabel('Frequency')
plt.show()

```


    
![png](output_7_0.png)
    



```python
sns.histplot(df_drug['Na_to_K'],kde=True)
plt.title('Na_to_K Distribution')
plt.xlabel('Na_to_K')
plt.ylabel('Frequency')
plt.show()

```


    
![png](output_8_0.png)
    


# Dataset Preparation


```python
#  The age will be divided into 7 age categories:

# Below 20 y.o.
# 20 - 29 y.o.
# 30 - 39 y.o.
# 40 - 49 y.o.
# 50 - 59 y.o.
# 60 - 69 y.o.
# Above 70.
```


```python
bin_age = [0, 19, 29, 39, 49, 59, 69, 80]
category_age = ['<20s', '20s', '30s', '40s', '50s', '60s', '>60s']
df_drug['Age_binned'] = pd.cut(df_drug['Age'], bins=bin_age, labels=category_age)
df_drug = df_drug.drop(['Age'], axis = 1)
```


```python
bin_NatoK = [0, 9, 19, 29, 50]
category_NatoK = ['<10', '10-20', '20-30', '>30']
df_drug['Na_to_K_binned'] = pd.cut(df_drug['Na_to_K'], bins=bin_NatoK, labels=category_NatoK)
df_drug = df_drug.drop(['Na_to_K'], axis = 1)
```


```python
# The dataset will be split into 70% training and 30% testing.
```


```python
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
```


```python
X = df_drug.drop(["Drug"], axis=1)
y = df_drug["Drug"]
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.3, random_state = 0)
```


```python
X_train = pd.get_dummies(X_train)
X_test = pd.get_dummies(X_test)
```


```python
X_train.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Sex_F</th>
      <th>Sex_M</th>
      <th>BP_HIGH</th>
      <th>BP_LOW</th>
      <th>BP_NORMAL</th>
      <th>Cholesterol_HIGH</th>
      <th>Cholesterol_NORMAL</th>
      <th>Age_binned_&lt;20s</th>
      <th>Age_binned_20s</th>
      <th>Age_binned_30s</th>
      <th>Age_binned_40s</th>
      <th>Age_binned_50s</th>
      <th>Age_binned_60s</th>
      <th>Age_binned_&gt;60s</th>
      <th>Na_to_K_binned_&lt;10</th>
      <th>Na_to_K_binned_10-20</th>
      <th>Na_to_K_binned_20-30</th>
      <th>Na_to_K_binned_&gt;30</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>131</th>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
    </tr>
    <tr>
      <th>96</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
    </tr>
    <tr>
      <th>181</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>19</th>
      <td>True</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
    </tr>
    <tr>
      <th>153</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
</div>




```python
X_test.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Sex_F</th>
      <th>Sex_M</th>
      <th>BP_HIGH</th>
      <th>BP_LOW</th>
      <th>BP_NORMAL</th>
      <th>Cholesterol_HIGH</th>
      <th>Cholesterol_NORMAL</th>
      <th>Age_binned_&lt;20s</th>
      <th>Age_binned_20s</th>
      <th>Age_binned_30s</th>
      <th>Age_binned_40s</th>
      <th>Age_binned_50s</th>
      <th>Age_binned_60s</th>
      <th>Age_binned_&gt;60s</th>
      <th>Na_to_K_binned_&lt;10</th>
      <th>Na_to_K_binned_10-20</th>
      <th>Na_to_K_binned_20-30</th>
      <th>Na_to_K_binned_&gt;30</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>18</th>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>170</th>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>107</th>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
    </tr>
    <tr>
      <th>98</th>
      <td>False</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
    </tr>
    <tr>
      <th>177</th>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
</div>




```python
from imblearn.over_sampling import SMOTE
X_train = X_train.astype(float)# or .astype(int) if appropriate
X_train, y_train = SMOTE().fit_resample(X_train, y_train)
# alternative code
# for col in X_train.columns:
#     if X_train[col].dtype == 'bool':
#         X_train[col] = X_train[col].astype(int)

```


```python
sns.set_theme(style="darkgrid")
sns.countplot(y=y_train,hue=y_train, palette="mako_r", legend=False)
plt.ylabel('Drug Type')
plt.xlabel('Total')
plt.show()


```


    
![png](output_20_0.png)
    



```python
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
DTclassifier = DecisionTreeClassifier(max_leaf_nodes=20)
DTclassifier.fit(X_train, y_train)

y_pred = DTclassifier.predict(X_test)

print("Classification Report:\n", classification_report(y_test, y_pred))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))

DTAcc = accuracy_score(y_test, y_pred)
print(f"Decision Tree Accuracy: {DTAcc:.2%}")
```

    Classification Report:
                   precision    recall  f1-score   support
    
           drugA       0.67      0.80      0.73         5
           drugB       0.75      1.00      0.86         3
           drugC       0.67      1.00      0.80         4
           drugX       0.82      1.00      0.90        18
           drugY       0.95      0.70      0.81        30
    
        accuracy                           0.83        60
       macro avg       0.77      0.90      0.82        60
    weighted avg       0.86      0.83      0.83        60
    
    Confusion Matrix:
     [[ 4  0  0  0  1]
     [ 0  3  0  0  0]
     [ 0  0  4  0  0]
     [ 0  0  0 18  0]
     [ 2  1  2  4 21]]
    Decision Tree Accuracy: 83.33%
    


```python
from sklearn.tree import plot_tree
import matplotlib.pyplot as plt

plt.figure(figsize=(12, 8))
plot_tree(DTclassifier, filled=True, feature_names=X_train.columns, class_names=True)
plt.show()
```


    
![png](output_22_0.png)
    



```python
from sklearn.model_selection import GridSearchCV

param_grid = {'max_leaf_nodes': [10, 20, 30, None], 'max_depth': [None, 5, 10]}
grid_search = GridSearchCV(DecisionTreeClassifier(), param_grid, cv=5)
grid_search.fit(X_train, y_train)
print("Best parameters:", grid_search.best_params_)

```

    Best parameters: {'max_depth': 10, 'max_leaf_nodes': 30}
    


```python
from sklearn.tree import DecisionTreeClassifier
scoreListDT = []
for i in range(2,50):
    DTclassifier = DecisionTreeClassifier(max_leaf_nodes=i)
    DTclassifier.fit(X_train, y_train)
    scoreListDT.append(DTclassifier.score(X_test, y_test))    
# Plot accuracy vs. leaf nodes
plt.plot(range(2, 50), scoreListDT, marker='o')
plt.xticks(np.arange(2, 50, 5))
plt.xlabel("Max Leaf Nodes")
plt.ylabel("Accuracy")
plt.title("Decision Tree Accuracy vs Leaf Nodes")
plt.grid(True)
plt.show()
# Best accuracy
best_acc = max(scoreListDT)
print(f"Best Decision Tree Accuracy: {best_acc:.2%}")
```


    
![png](output_24_0.png)
    


    Best Decision Tree Accuracy: 85.00%
    


```python
from sklearn.ensemble import RandomForestClassifier

RFclassifier = RandomForestClassifier(max_leaf_nodes=30)
RFclassifier.fit(X_train, y_train)

y_pred = RFclassifier.predict(X_test)

print(classification_report(y_test, y_pred))
print(confusion_matrix(y_test, y_pred))

from sklearn.metrics import *
RFAcc = accuracy_score(y_pred,y_test)
print(f"Random Forest accuracy is:{RFAcc:.2%}")
```

                  precision    recall  f1-score   support
    
           drugA       0.57      0.80      0.67         5
           drugB       0.75      1.00      0.86         3
           drugC       0.67      1.00      0.80         4
           drugX       0.82      1.00      0.90        18
           drugY       0.95      0.67      0.78        30
    
        accuracy                           0.82        60
       macro avg       0.75      0.89      0.80        60
    weighted avg       0.85      0.82      0.81        60
    
    [[ 4  0  0  0  1]
     [ 0  3  0  0  0]
     [ 0  0  4  0  0]
     [ 0  0  0 18  0]
     [ 3  1  2  4 20]]
    Random Forest accuracy is:81.67%
    


```python
scoreListRF = []
for i in range(2,50):
    RFclassifier = RandomForestClassifier(n_estimators = 1000, random_state = 1, max_leaf_nodes=i)
    RFclassifier.fit(X_train, y_train)
    scoreListRF.append(RFclassifier.score(X_test, y_test))
    
plt.plot(range(2,50), scoreListRF)
plt.xticks(np.arange(2,50,5))
plt.xlabel("RF Value")
plt.ylabel("Score")
plt.show()
RFAccMax = max(scoreListRF)
print("RF Acc Max {:.2f}%".format(RFAccMax*100))
```


    
![png](output_26_0.png)
    


    RF Acc Max 85.00%
    


```python
from sklearn.metrics import accuracy_score

# Decision Tree
dt = DecisionTreeClassifier()
dt.fit(X_train, y_train)
DTAcc = accuracy_score(y_test, dt.predict(X_test)) * 100

# Decision Tree Max (e.g., with max_depth=5)
dt_max = DecisionTreeClassifier(max_depth=5)
dt_max.fit(X_train, y_train)
DTAccMax = accuracy_score(y_test, dt_max.predict(X_test)) * 100

# Random Forest
rf = RandomForestClassifier()
rf.fit(X_train, y_train)
RFAcc = accuracy_score(y_test, rf.predict(X_test)) * 100

# Random Forest Max (e.g., with more estimators or depth)
rf_max = RandomForestClassifier(n_estimators=200, max_depth=10)
rf_max.fit(X_train, y_train)
RFAccMax = accuracy_score(y_test, rf_max.predict(X_test)) * 100

```


```python
compare = pd.DataFrame({
    'Model': ['Decision Tree', 'Decision Tree Max', 'Random Forest', 'Random Forest Max'],
    'Accuracy (%)': [DTAcc, DTAccMax, RFAcc, RFAccMax]
})
# Display the DataFrame
print(compare)
```

                   Model  Accuracy (%)
    0      Decision Tree     80.000000
    1  Decision Tree Max     83.333333
    2      Random Forest     78.333333
    3  Random Forest Max     83.333333
    


```python

```
